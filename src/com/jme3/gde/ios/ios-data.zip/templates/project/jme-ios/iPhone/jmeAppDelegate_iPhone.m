#import "jmeAppDelegate_iPhone.h"

@implementation jmeAppDelegate_iPhone

@end
