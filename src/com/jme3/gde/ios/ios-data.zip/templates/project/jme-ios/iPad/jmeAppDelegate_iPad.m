#import "jmeAppDelegate_iPad.h"

@implementation jmeAppDelegate_iPad

@end
